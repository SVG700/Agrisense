"""
Configurable OpenCV preview pipeline for Agrisense Raspberry Pi cameras.

This module deliberately reports candidate blobs, not insect species/counts.
Production detections must continue to come from the configured inference model.

Environment overrides:
  AGRISENSE_VISION_WIDTH=960
  AGRISENSE_YELLOW_H_LOW=15
  AGRISENSE_YELLOW_H_HIGH=40
  AGRISENSE_YELLOW_S_LOW=70
  AGRISENSE_YELLOW_V_LOW=90
  AGRISENSE_BLOB_MAX_SAT=90
  AGRISENSE_MIN_AREA_FRAC=0.00004
  AGRISENSE_MAX_AREA_FRAC=0.01
"""
from __future__ import annotations

import base64
import os
from typing import Dict, List, Tuple

PIPELINE = [
    "Camera frame",
    "Resize",
    "HSV yellow-card segmentation",
    "Card-region extraction",
    "Low-saturation candidate segmentation",
    "Morphological cleanup",
    "Contour filtering",
]

def _env_int(name: str, default: int, low: int, high: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default
    return max(low, min(high, value))

def _env_float(name: str, default: float, low: float, high: float) -> float:
    try:
        value = float(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        return default
    if not (value == value):  # NaN guard
        return default
    return max(low, min(high, value))

def _thresholds() -> Tuple[Tuple[int, int, int], Tuple[int, int, int]]:
    h_low = _env_int("AGRISENSE_YELLOW_H_LOW", 15, 0, 179)
    h_high = _env_int("AGRISENSE_YELLOW_H_HIGH", 40, h_low, 179)
    s_low = _env_int("AGRISENSE_YELLOW_S_LOW", 70, 0, 255)
    v_low = _env_int("AGRISENSE_YELLOW_V_LOW", 90, 0, 255)
    return (h_low, s_low, v_low), (h_high, 255, 255)

def process(frame, width: int | None = None) -> Dict:
    """Return preview frame, diagnostic stages, normalized candidate boxes and metadata."""
    import cv2
    import numpy as np

    if frame is None or not hasattr(frame, "shape") or len(frame.shape) < 2:
        raise ValueError("frame must be a non-empty image array")
    if frame.size == 0:
        raise ValueError("frame must be a non-empty image array")

    original_h, original_w = frame.shape[:2]
    target_width = width or _env_int("AGRISENSE_VISION_WIDTH", 960, 160, 4096)
    target_width = max(160, min(4096, int(target_width)))
    if original_w > target_width:
        target_height = max(1, round(original_h * target_width / original_w))
        img = cv2.resize(frame, (target_width, target_height), interpolation=cv2.INTER_AREA)
    else:
        img = frame.copy()

    h, w = img.shape[:2]
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    yellow_lo, yellow_hi = _thresholds()
    yellow = cv2.inRange(hsv, yellow_lo, yellow_hi)

    close_size = _env_int("AGRISENSE_CARD_CLOSE_KERNEL", 15, 3, 51)
    if close_size % 2 == 0:
        close_size += 1
    card_kernel = np.ones((close_size, close_size), np.uint8)
    yellow = cv2.morphologyEx(yellow, cv2.MORPH_CLOSE, card_kernel)

    contours, _ = cv2.findContours(yellow, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    card = np.zeros((h, w), np.uint8)
    card_found = False
    card_area_fraction = 0.0
    if contours:
        largest = max(contours, key=cv2.contourArea)
        area = float(cv2.contourArea(largest))
        card_area_fraction = area / float(h * w)
        min_card_fraction = _env_float("AGRISENSE_MIN_CARD_AREA_FRAC", 0.05, 0.001, 0.95)
        if card_area_fraction >= min_card_fraction:
            cv2.drawContours(card, [largest], -1, 255, thickness=cv2.FILLED)
            card_found = True

    # Avoid silently counting the entire scene when the yellow card is missing.
    if card_found:
        candidate_region = card
    else:
        candidate_region = np.zeros((h, w), np.uint8)

    max_sat = _env_int("AGRISENSE_BLOB_MAX_SAT", 90, 0, 255)
    low_sat = cv2.inRange(hsv[:, :, 1], 0, max_sat)
    blobs = cv2.bitwise_and(low_sat, candidate_region)

    morph_size = _env_int("AGRISENSE_BLOB_KERNEL", 3, 1, 15)
    if morph_size % 2 == 0:
        morph_size += 1
    kernel = np.ones((morph_size, morph_size), np.uint8)
    blobs = cv2.morphologyEx(blobs, cv2.MORPH_OPEN, kernel)
    blobs = cv2.morphologyEx(blobs, cv2.MORPH_CLOSE, kernel)

    found, _ = cv2.findContours(blobs, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    min_area = _env_float("AGRISENSE_MIN_AREA_FRAC", 0.00004, 0.0, 0.1) * h * w
    max_area = _env_float("AGRISENSE_MAX_AREA_FRAC", 0.01, min_area / (h * w), 0.5) * h * w

    boxes: List[Dict] = []
    for contour in found:
        area = float(cv2.contourArea(contour))
        if min_area <= area <= max_area:
            x, y, bw, bh = cv2.boundingRect(contour)
            boxes.append({
                "x": x / w, "y": y / h,
                "width": bw / w, "height": bh / h,
                "label": "candidate_blob",
                "area_px": int(area),
            })
    boxes.sort(key=lambda item: item["area_px"], reverse=True)

    tint = img.copy()
    if card_found:
        tint[card == 0] = (tint[card == 0] * 0.25).astype(np.uint8)
    mask_view = cv2.cvtColor(yellow, cv2.COLOR_GRAY2BGR)
    blob_view = cv2.cvtColor(blobs, cv2.COLOR_GRAY2BGR)
    overlay = img.copy()
    for box in boxes[:300]:
        x = int(box["x"] * w)
        y = int(box["y"] * h)
        bw = int(box["width"] * w)
        bh = int(box["height"] * h)
        cv2.rectangle(overlay, (x, y), (x + bw, y + bh), (0, 255, 0), 1)

    return {
        "frame": overlay,
        "stages": [
            ("Yellow-card mask", mask_view),
            ("Card region", tint),
            ("Candidate blobs", blob_view),
        ],
        "boxes": boxes[:300],
        "card_found": card_found,
        "card_area_fraction": round(card_area_fraction, 5),
        "candidate_count": len(boxes),
        "size": (w, h),
        "pipeline": PIPELINE + ([] if card_found else ["WARNING: yellow card not detected; candidate search skipped"]),
    }

def jpeg_b64(img, quality: int = 70) -> str:
    """Encode an image as base64 JPEG; fail loudly if OpenCV cannot encode it."""
    import cv2

    quality = max(20, min(95, int(quality)))
    ok, buffer = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok:
        raise RuntimeError("JPEG encoding failed")
    return base64.b64encode(buffer.tobytes()).decode("ascii")
