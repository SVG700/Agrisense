# Farhan's Agrisense Raspberry Pi / image-processing contribution

This contribution package updates `edge-simulator/agrisense_edge/vision.py` and adds
`edge-simulator/tests/test_vision.py`.

## What changes
- Adds environment-configurable HSV thresholds and morphology/area limits.
- Refuses to search the entire scene when a yellow sticky card is not found.
- Returns card-area and candidate-count diagnostics.
- Labels detections as candidate blobs, not insect species.
- Sorts candidates consistently and keeps bounding boxes normalized.
- Validates empty frames and JPEG encoding failures.
- Adds hardware-independent synthetic-image tests.

## Apply to the repository

From the cloned `Agrisense` repository root, copy these two files over the matching
paths, then run:

```bash
cd edge-simulator
python -m unittest discover -s tests -v
```

Install test/runtime dependencies if needed:

```bash
python -m pip install numpy opencv-python
```

On Raspberry Pi OS, use the repository's Picamera2 setup instructions and run the
agent with the system camera libraries available to its Python environment.

## Suggested calibration
Start with defaults. If the yellow card is missed, adjust `AGRISENSE_YELLOW_H_LOW`,
`AGRISENSE_YELLOW_H_HIGH`, `AGRISENSE_YELLOW_S_LOW`, and
`AGRISENSE_YELLOW_V_LOW` using captured images from the actual trap lighting.
Tune blob area bounds only after reviewing the diagnostic mask images.

## Important scope
This is a preview/candidate segmentation pipeline. It is not a validated insect
classifier and must not be used alone to make pesticide/spray decisions. The
project's configured inference provider remains responsible for species detection.
